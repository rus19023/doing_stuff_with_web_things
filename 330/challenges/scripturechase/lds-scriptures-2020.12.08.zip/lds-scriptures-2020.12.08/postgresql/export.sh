pg_dump --create --no-owner scriptures
